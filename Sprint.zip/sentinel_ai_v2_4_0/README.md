# Sentinel AI

## Version 2.4.0: Functional Completion Build

This build completes the remaining planned core app functions:

```text
Live MT5 connection
Live chart
Symbol selection and persistence
Market structure, support/resistance, liquidity, imbalance, momentum analysis
Confidence scoring
Entry validation
Risk/reward plan generation
Manual trade review
Manual MT5 order placement
Adaptive filling-mode fallback
Sentinel-owned trade ledger
Open trade tracking
Pending close settlement
TP/SL close result resolver
Closed-trade statistics
Ledger tools
Pending history repair
Ledger export
Guarded reset
Simplified dashboard
Guarded auto-trade execution
```

## Guarded Auto Trade

Auto Trade is now functional but remains default OFF.

Toolbar:

```text
Auto Trade: OFF
```

When enabled, the app asks for confirmation first.

Auto Trade only places an order when all guardrails pass:

```text
BUY_READY or SELL_READY only
valid TP/SL plan only
configured minimum confidence met
configured minimum risk/reward met
one trade at a time
no active Sentinel trade open
volume within configured max volume
duplicate same-plan submission blocked
```

Auto trades are saved to the Sentinel ledger as:

```text
SENTINEL_APP_AUTO
```

Manual trades remain saved as:

```text
SENTINEL_APP_MANUAL
```

Both count in app accuracy only after MT5 confirms the close result.

## Important Safety Defaults

```text
auto_trade_enabled: false
one_trade_at_a_time: true
minimum_confidence: 75.0
default_risk_reward: 2.0
```

## Main Dashboard

Visible rows remain user-focused:

```text
Today's Trades
Win Rate
Loss Rate
Net P/L
Open Trades
Closed Trades
Ledger Win Rate
Ledger Net P/L
Lifecycle Stage
Result Status
Last Result
Last Close Type
Active Position
Open P/L
Position Ticket
Protection Status
Ledger Warning
```

Backend diagnostics stay in the app/ledger tools instead of the main dashboard.

## Ledger Tools

```text
Repair Pending History
Archive Stale Pending
Export Ledger
Reset Test Ledger
```

Reset is blocked while an active Sentinel trade is open.

## Expected Trade Flow

### Open trade

```text
Open Trades: 1
Closed Trades: 0
Today's Trades: 0
Lifecycle Stage: ACTIVE_OPEN
```

### Closed but MT5 history still settling

```text
Open Trades: 0
Closed Trades: 0
Today's Trades: 0
Lifecycle Stage: PENDING_CLOSE_SETTLEMENT
```

### Close resolved

```text
Open Trades: 0
Closed Trades: 1
Today's Trades: 1
Win Rate: 100.00% or 0.00%
Net P/L: updated
Last Result: WIN / LOSS / BREAKEVEN
Last Close Type: TP HIT / SL HIT / MANUAL CLOSE
Lifecycle Stage: CLOSED_VERIFIED
```

## Run

```powershell
cd D:\projects\sentinelai
.\.venv\Scripts\Activate.ps1
python scripts\validate_sprint.py
$env:PYTHONPATH="src"
python -m sentinel_ai.main
```

## Validation

Expected validator result includes:

```text
guarded auto-trade completion ready
```

## Testing Reminder

Use demo first. Auto Trade can send real MT5 market orders when enabled and confirmed.
